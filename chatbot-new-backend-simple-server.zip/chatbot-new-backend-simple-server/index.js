import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv'
import botRoute from './routes/bot_route.js';
dotenv.config({quiet:true});
const app = express();
const PORT = process.env.PORT || 7001;

app.use(cors());
app.use(express.json());
app.use('/api', botRoute);

app.listen(PORT,()=>{
    console.log(`Server is running on port ${PORT}`);
});
