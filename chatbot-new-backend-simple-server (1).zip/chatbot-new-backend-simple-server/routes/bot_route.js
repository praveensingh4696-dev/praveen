import express from 'express';
import { botResponse } from '../controllers/bot_controller.js';

const router = express.Router();

router.get('/bot', botResponse);

export default router;